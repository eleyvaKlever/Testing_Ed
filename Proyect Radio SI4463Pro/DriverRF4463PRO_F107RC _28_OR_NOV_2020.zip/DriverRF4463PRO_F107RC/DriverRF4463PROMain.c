#include "STM32F107RCDefs.h"            // definiciones de Hardware para micro especifico
#include "DriverSPI.c"
#include "ConfigRF4463PRO.h"            // configuracion para RF4463PRO
#include "DriverRF4463PROdefs.c"        // Definiciones para RF4463PRO
#include "DriverRF4463PRO.c"            // Libreria para RF4463PRO

#define NULL ( ( void * )0 )
#define _NULL   ( char )0
#define PIN_LEVEL_LOW   0
#define PIN_LEVEL_HIGH  1

#include "utils.c"
#include "UARTHandler.c"
#include "Debug.c"

void RFISR() iv IVT_INT_EXTI15_10 ics ICS_AUTO{
    if( EXTI_PR.B12 ){
        EXTI_PR.B12 |= 1;
        LED_RED = 1;
        ucRF4463IRQ = 1;
        UART1_Write_Text( "RF int\r\n" );
        //vRF4463ClearInterrupts();
    }
}

void Timer2_interrupt() iv IVT_INT_TIM2 {
     TIM2_SR.UIF = 0;
     Flag.rf_reach_timeout = 1; //Enter your code here
     Flag.reach_1s = 1;
}


void vRF4463MainCommandProcessor ( ) {

}



//Timer2 Prescaler :1124; Preload = 63999; Actual Interrupt Time = 1
//Place/Copy this part in declaration section
void InitTimer2(){
     RCC_APB1ENR.TIM2EN = 1;
     TIM2_CR1.CEN = 0;
     TIM2_PSC = 1124;
     TIM2_ARR = 63999;
     NVIC_IntEnable(IVT_INT_TIM2);
     TIM2_DIER.UIE = 1;
     TIM2_CR1.CEN = 1;
}



void main() {
     
     unsigned char  i, j, chksum;
     
     Delay_ms( 2000 );                    // delay de depuracion
     
     // Basic Init
     // LEDS
     GPIO_Digital_Output( &GPIOC_BASE, _GPIO_PINMASK_6 );
     GPIO_Digital_Output( &GPIOC_BASE, _GPIO_PINMASK_7 );
     GPIO_Digital_Output( &GPIOC_BASE, _GPIO_PINMASK_8 );
     
     //GPIO_Digital_Input( &GPIOC_BASE, _GPIO_PINMASK_12 );
     /*********************************************************************
     * RF4463Pro I/O Setup
     *********************************************************************/
     GPIO_Digital_Input( &GPIOC_BASE, _GPIO_PINMASK_12 );

     GPIO_Digital_Output( &GPIOB_BASE, _GPIO_PINMASK_12 );
     GPIO_Digital_Output( &GPIOB_BASE, _GPIO_PINMASK_11 );
     GPIO_Digital_Output( &GPIOC_BASE, _GPIO_PINMASK_11 );
     GPIO_Digital_Output( &GPIOC_BASE, _GPIO_PINMASK_10 );
     
     /********************************************************
     * Clock Enable
     ********************************************************/
            RCC_APB2ENRbits.AFIOEN = 1;
        /********************************************************
         * Pin Configuration
        ********************************************************/
            AFIO_EXTICR4  |= 0x0002;
        /********************************************************
         * Interruption Edge Flag
        ********************************************************/
            EXTI_IMR.B12    |= 1;
            EXTI_FTSR.B12   |= 1;
     
     GPIO_Digital_Output( &GPIOB_BASE, _GPIO_PINMASK_7 );
     Sound_Init( &GPIOB_ODR, 7 );
     //Sound_Play( 1000, 100 );
     
     nSEL = 1;
     
     LED_RED      = 1;
     LED_GREEN    = 1;
     LED_BLUE     = 1;
     
     Delay_ms( 100 );
     
     LED_RED      = 0;
     LED_GREEN    = 1;
     LED_BLUE     = 0;
     
     InitTimer2();
     
     // Init driver ( MCU Specific )
     vUARTTxInit();                // configura todos las parametros de USART
     vSPI2Init();                  // configura todos los parametros de SPI
     
     // ESTABLECE PARAMETROS DEFAULT POR COMPILACION
     
     // rangos de 0 a 9
     freq3 = 9;
     freq2 = 1;
     freq1 = 5;
     
     // rangos de 0 a 7
     power = 1;
     
     rate  = dr_1p2;
     
     mode  = rx_test_mode;          // para transmision continua usar: tx_test_mode
     
     reset_mode = 0;
     
     // Init Device
     //ucRF4463Setup( RF4463_DEFAULT_CHANNEL, RF4463_DEFAULT_CHANNEL, RF4463_DEFAULT_NETWORK, RF4463_DEFAULT_TX_POWER );
     VRF4463SDNReset();
     vRF4463Init();
     vRF4463ClearInterrupts();
     vRF4463ClearInterrupts();
     vRF4463ClearInterrupts();
     vRF4463PartInfo ();
     
     LED_GREEN    = 0;
     LED_BLUE     = 0;
     
     UART1_Write_Text( "RF Radio ready" );
     
     while ( 1 ) {
           // Espera comando para realizar cierta accion
           if ( ucRF4463IRQ ) {
              ucRF4463IRQ = 0;       // limpia bandera
              spi_read_fifo();       // Read RX FIFO
              vRF4463FifoReset();    // FIFO RESET
              UART1_Write_Text( spi_read_buf );
           }


           if ( mode == master_mode ) {
              vRF4463TxData();
           }
           
           else if ( mode == slave_mode ) {
                vRF4463RxInit();
           }
           
           if ( mode == tx_test_mode ) {
              vRF4463TxCont();
              while ( 1 ) {
                    if ( !nIRQ ) {
                       vRF4463TxCont();
                    }
              }
           }
           
           if ( mode == rx_test_mode ) {
              vRF4463RxInit ();
              while ( 1 ) {
                    //spi_read_fifo();           // Lee ceros
              }
           }
           
           if ( reset_mode == 0 ) {
              
              while ( 1 ) {
                    
                    if ( Flag.reach_1s ) {
                       Flag.reach_1s = 0;
                       if ( mode == master_mode ) {
                          vRF4463TxData();
                       }

                    }
                    
                    // recibiendo optimo !!
                    if ( !Flag.is_tx ) {
                       if ( !nIRQ ) {          // !nIRQ
                          vRF4463ClearInterrupts();
                          
                          if ( ( spi_read_buf[ 4 ] & 0x08) == 0 ) { // crc error check
                          
                             spi_read_fifo();
                             vRF4463FifoReset();
                          
                             chksum = 0;
                             for ( i = 4; i < payload_length - 1; i++ )		// Calculation Checksum
                                 chksum += rx_buf[ i ];

                             if ( ( chksum == rx_buf[ payload_length - 1 ] )&&( rx_buf[ 4 ] == 0x41 )) {
                             
                                UART1_Write_Text( rx_buf );
                              
                                LED_GREEN ^= 1;					// Data received
                                rx_cnt++;

                                //if ( ( mode == slave_mode )&& ( set == 0 ) ) {
                                //   delay_1ms(100);
                                //   tx_data();
                                //}
                             }
                             else
                                 vRF4463RxInit();    // The received data is wrong, you must continue to receive
                          }
                          else {
                               UART1_Write_Text("[ CRC ] Fail\r\n");
                               VRF4463SDNReset();
                               vRF4463Init();
                               vRF4463RxInit();
                          }
                       }
                    }
              }
           }
     }
}