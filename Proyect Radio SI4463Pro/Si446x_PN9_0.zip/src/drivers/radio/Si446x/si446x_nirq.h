/*!
 * Silicon Laboratories Confidential
 * Copyright 2011 Silicon Laboratories, Inc.
 *
 * Public API for the Si446x nIRQ interface.
 */

#ifndef _SI446X_NIRQ_H
#define _SI446X_NIRQ_H


                /* ======================================= *
                 *              I N C L U D E              *
                 * ======================================= */

                /* ======================================= *
                 *          D E F I N I T I O N S          *
                 * ======================================= */

                /* ======================================= *
                 *     G L O B A L   V A R I A B L E S     *
                 * ======================================= */

                /* ======================================= *
                 *  F U N C T I O N   P R O T O T Y P E S  *
                 * ======================================= */


#endif //_SI446X_NIRQ_H
