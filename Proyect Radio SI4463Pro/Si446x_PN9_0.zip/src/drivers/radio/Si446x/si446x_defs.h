/*!
 * Silicon Laboratories Confidential
 * Copyright 2011 Silicon Laboratories, Inc.
 *
 */

#ifndef _SI446X_DEFS_H_
#define _SI446X_DEFS_H_

#include "si446x_cmd.h"

#include "si446x_prop.h"

#endif // _SI446X_DEFS_H_
