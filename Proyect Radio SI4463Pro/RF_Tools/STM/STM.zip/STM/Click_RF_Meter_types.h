#ifndef _RFMETER_T_
#define _RFMETER_T_

#include "stdint.h"

#ifndef _RFMETER_H_

#define T_RFMETER_P const uint8_t* 

#endif
#endif