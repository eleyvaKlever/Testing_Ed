Arduino Library for AD7887 ADC

Simple library to access the AD7887 ADC with an Arduino. The work is based on Makis's work (https://www.sv1afn.com/ad8318.html).

All documentation is inside the header file AD7887.h

73

Dietmar, DL2SBA